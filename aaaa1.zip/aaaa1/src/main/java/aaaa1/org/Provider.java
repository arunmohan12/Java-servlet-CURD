package aaaa1.org;

public interface Provider {
	String url="jdbc:postgresql://localhost:5432/postgres";
	String username="postgres";
	String password="arun2723";

}


